import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API route for birthday messages if we need to expand in the future
  app.get('/api/birthday-messages', (req, res) => {
    const messages = [
      "Happy Birthday to my amazing friend! 🎉",
      "You light up everyone's day with your smile! ✨",
      "Gaming buddies forever! 🎮",
      "You're stellar - just like the stars! 🌟",
      "Coffee date soon? ☕",
      "You're the best clown in the universe! 🤡💜",
      "Thanks for always being there for me! 💕",
      "Wishing you a magical birthday! 🎂",
      "You're out of this world awesome! 🚀",
      "Purple suits you perfectly! 💜"
    ];
    
    res.json({ messages });
  });

  const httpServer = createServer(app);

  return httpServer;
}
