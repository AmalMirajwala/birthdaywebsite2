import { motion } from "framer-motion";

export default function Header() {
  return (
    <div className="text-center mb-4 mt-8">
      <motion.h1
        className="font-['Bubblegum_Sans',_cursive] text-4xl md:text-6xl text-[#FFD1DC] mb-2"
        animate={{ opacity: [0.7, 1, 0.7] }}
        transition={{
          repeat: Infinity,
          duration: 3,
        }}
      >
        Happy Birthday!
      </motion.h1>
      <p className="font-['Comic_Neue',_cursive] text-xl text-[#FFFACD]">
        To my Clownie! ✨
      </p>
    </div>
  );
}
