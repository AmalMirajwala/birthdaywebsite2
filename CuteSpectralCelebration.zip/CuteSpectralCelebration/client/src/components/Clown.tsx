import { motion } from "framer-motion";
import { useAudio } from "@/hooks/use-audio";

interface ClownProps {
  onClick: () => void;
}

export default function Clown({ onClick }: ClownProps) {
  const { playSound } = useAudio();
  
  const handleClick = () => {
    playSound('click');
    onClick();
  };
  
  return (
    <motion.div
      className="absolute right-1/4 transform translate-x-1/2 bottom-0 cursor-pointer z-10"
      style={{
        filter: "drop-shadow(0 0 5px rgba(255, 255, 255, 0.7))",
      }}
      animate={{ 
        y: [0, -15, 0],
        rotate: [0, 1, 0, -1, 0]
      }}
      transition={{
        repeat: Infinity,
        duration: 8,
        ease: "easeInOut",
      }}
      whileTap={{ scale: 1.1 }}
      onClick={handleClick}
    >
      <svg width="150" height="200" viewBox="0 0 150 200" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Party Hat */}
        <path
          d="M75 10L45 60H105L75 10Z"
          fill="#BA55D3"
          stroke="black"
          strokeWidth="2"
        />
        <path
          d="M50 60C50 60 75 50 100 60"
          stroke="black"
          strokeWidth="2"
          strokeDasharray="4 2"
        />
        <path
          d="M60 35C60 35 75 30 90 35"
          stroke="black"
          strokeWidth="2"
          strokeDasharray="4 2"
        />
        
        {/* Clown Hair */}
        <path
          d="M45 60C30 50 35 35 45 35C25 30 30 15 40 15C50 15 55 25 60 30C65 15 75 10 85 15C95 20 100 35 100 40C110 35 115 40 115 45C115 50 105 60 105 60"
          fill="#FF6347"
          stroke="black"
          strokeWidth="1.5"
        />
        
        {/* Hair Puffs */}
        <circle cx="55" cy="35" r="8" fill="#FF6347" stroke="black" strokeWidth="1" />
        <circle cx="95" cy="35" r="8" fill="#FF6347" stroke="black" strokeWidth="1" />
        <circle cx="75" cy="25" r="10" fill="#FF6347" stroke="black" strokeWidth="1" />
        
        {/* Hair Highlights */}
        <path
          d="M50 30C50 30 55 28 58 32"
          stroke="white"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
        <path
          d="M70 20C70 20 75 18 78 22"
          stroke="white"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
        <path
          d="M90 30C90 30 95 28 98 32"
          stroke="white"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
        
        {/* Clown Face */}
        <circle cx="75" cy="85" r="35" fill="#FFD1DC" stroke="black" strokeWidth="1.5" />
        
        {/* Frilly Collar */}
        <path
          d="M45 105C45 105 50 95 55 105C60 115 65 105 70 105C75 95 80 115 85 105C90 95 95 115 100 105C105 95 110 105 115 105"
          stroke="black"
          strokeWidth="2"
          fill="#FFFACD"
        />
        
        {/* Eyes */}
        <circle cx="65" cy="80" rx="6" ry="8" fill="white" stroke="black" strokeWidth="1" />
        <circle cx="85" cy="80" rx="6" ry="8" fill="white" stroke="black" strokeWidth="1" />
        <circle cx="65" cy="82" r="3" fill="black" />
        <circle cx="85" cy="82" r="3" fill="black" />
        
        {/* Nose */}
        <circle cx="75" cy="90" r="8" fill="#FF6347" stroke="black" strokeWidth="1" />
        <ellipse cx="72" cy="87" rx="2" ry="1" fill="white" />
        
        {/* Smile */}
        <path
          d="M60 100C60 105 90 105 90 100"
          stroke="black"
          strokeWidth="2"
          fill="none"
        />
        
        {/* Cheeks */}
        <circle cx="55" cy="95" r="5" fill="#FF6347" fillOpacity="0.5" />
        <circle cx="95" cy="95" r="5" fill="#FF6347" fillOpacity="0.5" />
        
        {/* Body */}
        <path
          d="M60 120H90V160C90 165.523 85.5228 170 80 170H70C64.4772 170 60 165.523 60 160V120Z"
          fill="#BA55D3"
          stroke="black"
          strokeWidth="1.5"
        />
        
        {/* Polka dots */}
        <circle cx="70" cy="135" r="5" fill="#FFFACD" />
        <circle cx="80" cy="150" r="5" fill="#FFFACD" />
        <circle cx="75" cy="120" r="5" fill="#FFFACD" />
        
        {/* Arms */}
        <path
          d="M60 130C60 130 40 125 35 135"
          stroke="black"
          strokeWidth="4"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M90 130C90 130 110 125 115 135"
          stroke="black"
          strokeWidth="4"
          strokeLinecap="round"
          fill="none"
        />
        
        {/* Hands */}
        <circle cx="35" cy="135" r="6" fill="#FFD1DC" stroke="black" strokeWidth="1" />
        <circle cx="115" cy="135" r="6" fill="#FFD1DC" stroke="black" strokeWidth="1" />
        
        {/* Feet */}
        <ellipse cx="70" cy="178" rx="8" ry="5" fill="#FFD1DC" stroke="black" strokeWidth="1" />
        <ellipse cx="80" cy="178" rx="8" ry="5" fill="#FFD1DC" stroke="black" strokeWidth="1" />
      </svg>
    </motion.div>
  );
}
