export default function Footer() {
  return (
    <div className="mt-10 text-center font-['Bubblegum_Sans',_cursive] text-white text-opacity-80 text-sm">
      <p>From Your Demon ❤️ </p>
    </div>
  );
}
