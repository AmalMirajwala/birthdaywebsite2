import { useEffect, useState } from "react";
import { motion } from "framer-motion";

const getRandomSize = () => Math.random() * 3 + 1;
const getRandomPosition = () => Math.random() * 100;
const getRandomDelay = () => Math.random() * 5;
const getRandomDuration = () => Math.random() * 3 + 3;

interface Star {
  id: number;
  size: number;
  left: number;
  top: number;
  delay: number;
}

const Star = ({ size, left, top, delay }: Omit<Star, "id">) => (
  <motion.div
    className="absolute rounded-full bg-white"
    style={{
      width: `${size}px`,
      height: `${size}px`,
      left: `${left}%`,
      top: `${top}%`,
    }}
    animate={{ opacity: [0.3, 1, 0.3] }}
    transition={{
      repeat: Infinity,
      duration: 2,
      delay,
      ease: "easeInOut",
    }}
  />
);

const Planet = ({ color, size, top, left, delay }: { color: string; size: number; top: number; left: number; delay: number }) => (
  <motion.div
    className={`absolute rounded-full ${color} opacity-40`}
    style={{
      width: `${size}px`,
      height: `${size}px`,
      top: `${top}%`,
      left: `${left}%`,
      boxShadow: "inset -10px -10px 15px rgba(0,0,0,0.5), 0 0 10px rgba(255,255,255,0.2)",
    }}
    animate={{ y: [0, -20, 0], rotate: [0, 10, 0] }}
    transition={{
      repeat: Infinity,
      duration: 15,
      delay,
      ease: "easeInOut",
    }}
  >
    {/* Planet ring */}
    <motion.div
      className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2"
      style={{
        width: `${size * 1.5}px`,
        height: `${size * 0.4}px`,
        borderRadius: "50%",
        border: "2px solid rgba(255, 255, 255, 0.3)",
        transform: "translate(-50%, -50%) rotateX(75deg)",
      }}
      animate={{ rotate: [0, 360] }}
      transition={{
        repeat: Infinity,
        duration: 30,
        ease: "linear",
      }}
    />
  </motion.div>
);

const GamePixel = ({ top, left, color, size, delay }: { top: number; left: number; color: string; size: number; delay: number }) => (
  <motion.div
    className={`absolute ${color}`}
    style={{ 
      top: `${top}%`, 
      left: `${left}%`,
      width: `${size}px`,
      height: `${size}px`,
    }}
    animate={{ 
      y: [0, -15, 0],
      opacity: [0.7, 1, 0.7],
      scale: [1, 1.1, 1]
    }}
    transition={{
      repeat: Infinity,
      duration: 4,
      delay,
      ease: "easeInOut",
    }}
  />
);

const Heart = ({ top, left, size, delay }: { top: number; left: number; size: number; delay: number }) => (
  <motion.div
    className="absolute"
    style={{ top: `${top}%`, left: `${left}%` }}
    animate={{ 
      y: [0, -10, 0],
      scale: [1, 1.1, 1],
      opacity: [0.7, 1, 0.7] 
    }}
    transition={{
      repeat: Infinity,
      duration: 3,
      delay,
      ease: "easeInOut",
    }}
  >
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path 
        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" 
        fill="#FF6347"
      />
    </svg>
  </motion.div>
);

const Coin = ({ top, left, size, delay }: { top: number; left: number; size: number; delay: number }) => (
  <motion.div
    className="absolute"
    style={{ top: `${top}%`, left: `${left}%` }}
    animate={{ rotateY: [0, 360] }}
    transition={{
      repeat: Infinity,
      duration: 2,
      delay,
      ease: "linear",
    }}
  >
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="12" cy="12" r="10" fill="#FFD700" stroke="#B8860B" strokeWidth="1" />
      <path d="M12 6V18" stroke="#B8860B" strokeWidth="1" />
      <path d="M8 12H16" stroke="#B8860B" strokeWidth="1" />
    </svg>
  </motion.div>
);

const GameController = ({ bottom, left }: { bottom: number; left: number }) => (
  <motion.div
    className="absolute"
    style={{ bottom: `${bottom}%`, left: `${left}%` }}
    animate={{ y: [0, -15, 0], rotate: [0, 2, 0, -2, 0] }}
    transition={{
      repeat: Infinity,
      duration: 8,
      ease: "easeInOut",
    }}
  >
    <svg width="70" height="50" viewBox="0 0 70 50" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="10" y="10" width="50" height="30" rx="15" fill="#BA55D3"/>
      <circle cx="25" cy="25" r="5" fill="#FF6347"/>
      <circle cx="45" cy="25" r="5" fill="#32CD32"/>
      <rect x="27.5" y="5" width="15" height="5" rx="2.5" fill="#BA55D3"/>
      <rect x="27.5" y="40" width="15" height="5" rx="2.5" fill="#BA55D3"/>
    </svg>
  </motion.div>
);

const Mushroom = ({ top, right, size, delay }: { top: number; right: number; size: number; delay: number }) => (
  <motion.div
    className="absolute"
    style={{ top: `${top}%`, right: `${right}%` }}
    animate={{ 
      y: [0, -10, 0],
      scale: [1, 1.1, 1] 
    }}
    transition={{
      repeat: Infinity,
      duration: 4,
      delay,
      ease: "easeInOut",
    }}
  >
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16 4C10 4 4 8 4 16H28C28 8 22 4 16 4Z" fill="#FF6347" stroke="black" strokeWidth="1" />
      <path d="M10 16L10 24H22L22 16" fill="#FFFFFF" stroke="black" strokeWidth="1" />
      <circle cx="12" cy="10" r="2" fill="white" />
      <circle cx="20" cy="10" r="2" fill="white" />
      <circle cx="16" cy="13" r="2" fill="white" />
    </svg>
  </motion.div>
);

export default function BackgroundElements() {
  const [stars, setStars] = useState<Star[]>([]);

  useEffect(() => {
    const starCount = 100;
    const newStars = Array.from({ length: starCount }, (_, i) => ({
      id: i,
      size: getRandomSize(),
      left: getRandomPosition(),
      top: getRandomPosition(),
      delay: getRandomDelay(),
    }));
    setStars(newStars);
  }, []);

  return (
    <div className="fixed w-full h-full z-0 overflow-hidden">
      {stars.map((star) => (
        <Star key={star.id} size={star.size} left={star.left} top={star.top} delay={star.delay} />
      ))}
      
      {/* Planets with rings */}
      <Planet color="bg-purple-900" size={100} top={15} left={10} delay={0} />
      <Planet color="bg-purple-500" size={60} top={70} left={80} delay={2} />
      <Planet color="bg-indigo-800" size={80} top={40} left={85} delay={1} />
      
      {/* Game pixels */}
      <GamePixel top={25} left={30} color="bg-pink-400" size={15} delay={0.5} />
      <GamePixel top={65} left={20} color="bg-blue-400" size={15} delay={1.2} />
      <GamePixel top={35} left={75} color="bg-green-400" size={15} delay={0.8} />
      <GamePixel top={75} left={40} color="bg-yellow-400" size={15} delay={1.5} />
      <GamePixel top={15} left={60} color="bg-red-400" size={15} delay={0.3} />
      
      {/* Hearts */}
      <Heart top={20} left={40} size={20} delay={0.2} />
      <Heart top={60} left={30} size={15} delay={1.0} />
      <Heart top={30} left={65} size={25} delay={0.7} />
      
      {/* Gaming elements */}
      <Coin top={45} left={25} size={30} delay={0.5} />
      <Coin top={25} left={55} size={25} delay={1.3} />
      <Mushroom top={15} right={25} size={40} delay={0.4} />
      <GameController bottom={15} left={15} />
    </div>
  );
}
