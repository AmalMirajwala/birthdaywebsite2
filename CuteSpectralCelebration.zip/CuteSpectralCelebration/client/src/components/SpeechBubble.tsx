import { motion, AnimatePresence } from "framer-motion";

interface SpeechBubbleProps {
  message: string;
  isVisible: boolean;
}

export default function SpeechBubble({ message, isVisible }: SpeechBubbleProps) {
  return (
    <AnimatePresence mode="wait">
      {isVisible && (
        <motion.div
          className="absolute top-0 left-1/2 transform -translate-x-1/4 w-64 md:w-80 text-center z-30"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1, y: [0, -5, 0] }}
          exit={{ opacity: 0, scale: 0.8 }}
          transition={{ 
            duration: 0.5,
            y: {
              repeat: Infinity,
              duration: 2,
              ease: "easeInOut"
            }
          }}
        >
          <div className="relative bg-[#BA55D3] rounded-3xl p-4 m-1 border-2 border-white text-white shadow-lg">
            <div className="absolute inset-0 bg-white opacity-10 rounded-3xl"></div>
            <p className="text-lg font-bold font-['Comic_Neue',_cursive] drop-shadow-md">{message}</p>
            
            {/* Stars decoration in speech bubble */}
            <div className="absolute top-2 right-2">
              <motion.svg 
                width="15" 
                height="15" 
                viewBox="0 0 15 15" 
                fill="none" 
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 8, ease: "linear" }}
              >
                <path d="M7.5 0L9.5 5H15L10.5 8.5L12.5 14L7.5 10.5L2.5 14L4.5 8.5L0 5H5.5L7.5 0Z" fill="white" fillOpacity="0.5" />
              </motion.svg>
            </div>
            <div className="absolute bottom-2 left-3">
              <motion.svg 
                width="10" 
                height="10" 
                viewBox="0 0 15 15" 
                fill="none" 
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 10, ease: "linear" }}
              >
                <path d="M7.5 0L9.5 5H15L10.5 8.5L12.5 14L7.5 10.5L2.5 14L4.5 8.5L0 5H5.5L7.5 0Z" fill="white" fillOpacity="0.5" />
              </motion.svg>
            </div>
            
            {/* Speech bubble tail */}
            <div className="absolute bottom-0 left-[20%] w-0 h-0 border-[20px] border-transparent border-t-[#BA55D3] border-b-0 border-l-0 -mb-5 -ml-[10px]"></div>
            <div className="absolute bottom-0 left-[20%] w-0 h-0 border-[23px] border-transparent border-t-white border-b-0 border-l-0 -mb-6 -ml-[12px] opacity-50"></div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
