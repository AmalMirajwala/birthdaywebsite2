import { useEffect } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { useAudio } from '@/hooks/use-audio';
import { Button } from '@/components/ui/button';

export default function SoundControl() {
  const { isMuted, toggleMute, playSound } = useAudio();
  
  // Initialize background music when component mounts
  useEffect(() => {
    // Auto-play is blocked in most browsers until user interaction
    // So we just set up the audio here, but the user will need to click
    // the sound button to actually hear the music
    playSound('background', { loop: true, volume: 0.5 });
  }, [playSound]);

  return (
    <Button 
      variant="ghost" 
      size="icon" 
      className="fixed bottom-4 right-4 z-50 rounded-full bg-purple-900/50 hover:bg-purple-900/70 transition-all duration-300 h-12 w-12 backdrop-blur-sm"
      onClick={toggleMute}
      aria-label={isMuted ? "Unmute sounds" : "Mute sounds"}
    >
      {isMuted ? (
        <VolumeX className="h-6 w-6 text-purple-100" />
      ) : (
        <Volume2 className="h-6 w-6 text-purple-100" />
      )}
    </Button>
  );
}