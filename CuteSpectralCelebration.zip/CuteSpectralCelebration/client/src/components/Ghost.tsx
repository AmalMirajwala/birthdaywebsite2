import { motion } from "framer-motion";
import { useAudio } from "@/hooks/use-audio";

interface GhostProps {
  onClick: () => void;
}

export default function Ghost({ onClick }: GhostProps) {
  const { playSound } = useAudio();
  
  const handleClick = () => {
    playSound('sparkle');
    onClick();
  };
  
  return (
    <motion.div
      className="absolute left-1/4 transform -translate-x-1/2 top-1/4 cursor-pointer z-20"
      style={{
        filter: "drop-shadow(0 0 5px rgba(255, 255, 255, 0.7))",
      }}
      animate={{ y: [0, -20, 0] }}
      transition={{
        repeat: Infinity,
        duration: 6,
        ease: "easeInOut",
      }}
      whileTap={{ scale: 1.1 }}
      onClick={handleClick}
    >
      <svg width="150" height="170" viewBox="0 0 150 170" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Main ghost body with flowing bottom */}
        <path
          d="M75 10C52.909 10.6897 35 28.909 35 51V116C35 116 30 133 40 140C48 145.5 55 130 65 140C75 150 85 140 95 142.5C105 145 115 150 120 135C125 120 115 115 115 100V51C115 28.909 97.091 10.6897 75 10Z"
          fill="white"
          stroke="black"
          strokeWidth="2"
        />
        
        {/* Left eye base */}
        <ellipse cx="60" cy="55" rx="5" ry="7" fill="black" />
        {/* Left eye sparkle */}
        <circle cx="61" cy="53" r="1.5" fill="white" />
        <motion.circle 
          cx="58" 
          cy="57" 
          r="1" 
          fill="white" 
          animate={{ 
            opacity: [0, 1, 0],
            scale: [0.8, 1.2, 0.8]
          }}
          transition={{
            repeat: Infinity,
            duration: 2,
            repeatType: "reverse"
          }}
        />
        
        {/* Right eye base */}
        <ellipse cx="90" cy="55" rx="5" ry="7" fill="black" />
        {/* Right eye sparkle */}
        <circle cx="91" cy="53" r="1.5" fill="white" />
        <motion.circle 
          cx="88" 
          cy="57" 
          r="1" 
          fill="white" 
          animate={{ 
            opacity: [0, 1, 0],
            scale: [0.8, 1.2, 0.8]
          }}
          transition={{
            repeat: Infinity,
            duration: 2,
            repeatType: "reverse",
            delay: 0.5
          }}
        />
        
        {/* Cute smile */}
        <path
          d="M70 70C70 70 75 75 80 75C85 75 90 70 90 70"
          stroke="black"
          strokeWidth="2"
          strokeLinecap="round"
        />
        
        {/* Moon crescent */}
        <path
          d="M30 40C20 35 20 25 25 20C10 25 15 40 25 45C35 50 40 45 30 40Z"
          fill="white"
          stroke="black"
          strokeWidth="1.5"
        />
        
        {/* Bats */}
        <path
          d="M20 30C18 28 15 30 15 32C15 30 12 28 10 30C8 32 15 36 15 34C15 36 22 32 20 30Z"
          fill="black"
        />
        <path
          d="M45 20C43 18 40 20 40 22C40 20 37 18 35 20C33 22 40 26 40 24C40 26 47 22 45 20Z"
          fill="black"
        />
        <path
          d="M25 50C23 48 20 50 20 52C20 50 17 48 15 50C13 52 20 56 20 54C20 56 27 52 25 50Z"
          fill="black"
        />
        
        {/* Additional sparkle effects around ghost */}
        <motion.path
          d="M45 65C47 65 46 63 46 63C46 63 48 64 48 62C48 60 46 61 46 61C46 61 47 59 45 59C43 59 44 61 44 61C44 61 42 60 42 62C42 64 44 63 44 63C44 63 43 65 45 65Z"
          fill="white"
          fillOpacity="0.7"
          animate={{ scale: [0.9, 1.1, 0.9], rotate: [0, 15, 0] }}
          transition={{ repeat: Infinity, duration: 3 }}
        />
        
        <motion.path
          d="M100 45C102 45 101 43 101 43C101 43 103 44 103 42C103 40 101 41 101 41C101 41 102 39 100 39C98 39 99 41 99 41C99 41 97 40 97 42C97 44 99 43 99 43C99 43 98 45 100 45Z"
          fill="white"
          fillOpacity="0.7"
          animate={{ scale: [0.9, 1.1, 0.9], rotate: [0, -15, 0] }}
          transition={{ repeat: Infinity, duration: 3, delay: 1 }}
        />
      </svg>
    </motion.div>
  );
}
