import { useState, useEffect, useRef } from 'react';

type AudioType = 'background' | 'click' | 'sparkle';

interface AudioOptions {
  loop?: boolean;
  volume?: number;
  autoplay?: boolean;
}

export function useAudio() {
  const [isMuted, setIsMuted] = useState(true); // Start muted by default
  const audioRefs = useRef<Record<AudioType, HTMLAudioElement | null>>({
    background: null,
    click: null,
    sparkle: null
  });

  // Initialize audio elements
  useEffect(() => {
    // Create audio elements if they don't exist
    if (!audioRefs.current.background) {
      audioRefs.current.background = new Audio('/sounds/background-music.mp3');
      audioRefs.current.background.loop = true;
      audioRefs.current.background.volume = 0.5;
    }
    
    if (!audioRefs.current.click) {
      audioRefs.current.click = new Audio('/sounds/click.mp3');
      audioRefs.current.click.volume = 0.7;
    }
    
    if (!audioRefs.current.sparkle) {
      audioRefs.current.sparkle = new Audio('/sounds/sparkle.mp3');
      audioRefs.current.sparkle.volume = 0.6;
    }

    // Cleanup function
    return () => {
      Object.values(audioRefs.current).forEach(audio => {
        if (audio) {
          audio.pause();
          audio.src = '';
        }
      });
    };
  }, []);

  // Function to toggle mute/unmute for all audio
  const toggleMute = () => {
    setIsMuted(prev => !prev);
    
    Object.values(audioRefs.current).forEach(audio => {
      if (audio) {
        audio.muted = !isMuted;
      }
    });
    
    // Resume background music if we're unmuting
    if (isMuted && audioRefs.current.background) {
      audioRefs.current.background.play().catch(error => {
        // Just log the info but don't block the UI
        console.info("Note: background music couldn't be played. This is expected if the audio file isn't available yet.");
      });
    }
  };

  // Function to play a specific sound
  const playSound = (type: AudioType, options: AudioOptions = {}) => {
    const audio = audioRefs.current[type];
    if (!audio) return;
    
    // Apply options
    if (options.loop !== undefined) audio.loop = options.loop;
    if (options.volume !== undefined) audio.volume = options.volume;
    
    // Apply mute state
    audio.muted = isMuted;
    
    // Reset the audio to the beginning if it's already playing
    audio.currentTime = 0;
    
    // Play the audio with graceful error handling
    if (!isMuted) {
      audio.play().catch(error => {
        // Just log the error but don't block the UI
        console.info(`Note: ${type} sound couldn't be played. This is expected if the audio file isn't available yet.`);
      });
    }
  };

  // Function to stop a specific sound
  const stopSound = (type: AudioType) => {
    const audio = audioRefs.current[type];
    if (audio) {
      audio.pause();
      audio.currentTime = 0;
    }
  };

  return {
    isMuted,
    toggleMute,
    playSound,
    stopSound
  };
}