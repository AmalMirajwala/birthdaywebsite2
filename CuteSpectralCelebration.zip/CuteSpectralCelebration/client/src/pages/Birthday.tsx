import { useState, useEffect } from "react";
import BackgroundElements from "@/components/BackgroundElements";
import Ghost from "@/components/Ghost";
import Clown from "@/components/Clown";
import SpeechBubble from "@/components/SpeechBubble";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SoundControl from "@/components/SoundControl";

const messages = [
  "Happy Birthday my Twinnie! 🎉",
  "You, me, loft apartment? ✨",
  "PUBG when? 🎮",
  "I love you to the moon and back! 🌟",
  "One thing about me is that us being best friends for 15 years is my biggest flex 💖",
  "You're the best clown in the whole universe! 🤡💜",
  "Thanks for always being there for me! 💕",
  "Have a magical birthday! Eat a lot of umm broccoli?",
  "You're out of this world awesome! 🚀",
  "You're absolutely gorgeous to me! 💜",
  "You're better than the sister I prayed for! 💫",
  "You make my life so much better simply by existing! 💝",
  "BELLLARKE FOREVER!",
  "You deserve all the happiness in the universe! 🌌✨"
];

export default function Birthday() {
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);
  const [isMessageVisible, setIsMessageVisible] = useState(true);

  const showNextMessage = () => {
    setIsMessageVisible(false);
    
    setTimeout(() => {
      setCurrentMessageIndex((prevIndex) => (prevIndex + 1) % messages.length);
      setIsMessageVisible(true);
    }, 500);
  };

  useEffect(() => {
    const messageInterval = setInterval(() => {
      showNextMessage();
    }, 5000);

    return () => clearInterval(messageInterval);
  }, []);

  const handleGhostClick = () => {
    showNextMessage();
  };

  const handleClownClick = () => {
    // Easter egg: show a special message when clicking on the clown
    const specialMessage = "You clicked me! I'm ticklish! 😂";
    
    setIsMessageVisible(false);
    
    setTimeout(() => {
      setCurrentMessageIndex(messages.findIndex(msg => msg === specialMessage) !== -1 
        ? messages.findIndex(msg => msg === specialMessage)
        : messages.length); // Use existing message or temporarily add new one
      
      if (messages.findIndex(msg => msg === specialMessage) === -1) {
        messages.push(specialMessage);
      }
      
      setIsMessageVisible(true);
      
      // Revert back to normal messages after showing special message
      setTimeout(() => {
        if (messages.length > 14) { // Updated count to match new messages length
          messages.pop(); // Remove special message if it was added
        }
      }, 5000);
    }, 500);
  };

  // Add sparkle effect
  const [sparkles, setSparkles] = useState<{ id: number; x: number; y: number; size: number; duration: number }[]>([]);
  
  useEffect(() => {
    const createSparkle = () => {
      const x = Math.random() * 100;
      const y = Math.random() * 100;
      const size = Math.random() * 10 + 5;
      const duration = Math.random() * 2 + 1;
      
      setSparkles(prev => [
        ...prev,
        {
          id: Date.now(),
          x,
          y,
          size,
          duration
        }
      ]);
      
      // Remove sparkle after animation completes
      setTimeout(() => {
        setSparkles(prev => prev.filter(sparkle => sparkle.id !== Date.now()));
      }, duration * 1000);
    };
    
    const sparkleInterval = setInterval(createSparkle, 500);
    
    return () => clearInterval(sparkleInterval);
  }, []);

  return (
    <div className="bg-[#191970] min-h-screen overflow-x-hidden font-['Comic_Neue',_cursive]">
      <BackgroundElements />
      
      {/* Sparkles */}
      {sparkles.map((sparkle) => (
        <div
          key={sparkle.id}
          className="absolute w-3 h-3 rounded-full bg-white z-20 pointer-events-none"
          style={{
            left: `${sparkle.x}%`,
            top: `${sparkle.y}%`,
            width: `${sparkle.size}px`,
            height: `${sparkle.size}px`,
            boxShadow: '0 0 8px 2px rgba(255, 255, 255, 0.7)',
            animation: `sparkle ${sparkle.duration}s linear forwards`
          }}
        />
      ))}
      
      <style dangerouslySetInnerHTML={{
        __html: `
          @keyframes sparkle {
            0% {
              opacity: 0;
              transform: scale(0);
            }
            50% {
              opacity: 1;
              transform: scale(1);
            }
            100% {
              opacity: 0;
              transform: scale(0);
            }
          }
        `
      }} />
      
      <div className="container mx-auto px-4 min-h-screen relative z-10 flex flex-col items-center justify-center">
        <Header />
        
        <div className="relative w-full max-w-2xl h-[500px] mt-8">
          <Ghost onClick={handleGhostClick} />
          <SpeechBubble 
            message={messages[currentMessageIndex]} 
            isVisible={isMessageVisible} 
          />
          <Clown onClick={handleClownClick} />
        </div>
        
        <Footer />
        
        {/* Sound control button */}
        <SoundControl />
      </div>
    </div>
  );
}
